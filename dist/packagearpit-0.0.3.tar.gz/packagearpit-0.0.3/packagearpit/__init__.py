class Achha:
    def __init__(self):
        print("Constructorn is builded")

    def func(self, number):
        print("This is a arpit")
        return number