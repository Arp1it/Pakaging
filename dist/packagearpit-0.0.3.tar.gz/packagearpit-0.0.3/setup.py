from setuptools import setup

setup(name = "packagearpit",
version = "0.0.3",
description = "This is a arpit package",
long_description = "This a long description of packagearpit",
author = "arpit",
packages = ["packagearpit"],
install_requires = [])
