def achafunc(number):
    print("This is a arpit")
    return number